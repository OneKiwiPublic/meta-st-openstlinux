#!/bin/sh
BASE_DIR=/home/root/V3.4
APP_DIR=/usr/local/linuxapp

echo "======================INSTALL APPLICATION ========================="
systemctl stop app
#pkill -9 iot_manager
#echo 'A' | unzip $BASE_DIR/base/linuxapp.zip -d /usr/local/

echo "Create media folder"
mkdir -p $APP_DIR/bin/media

echo "======================SETUP  SYSTEM  ================================"
echo "Enable SSH access" 
echo "" > /etc/default/dropbear; cat /etc/default/dropbear

echo "Disable random service"
systemctl disable rngd

echo "Setup root password"
echo 'root:root00' | chpasswd

echo "Update DNS"
cp $BASE_DIR/base/resolved.conf  /etc/systemd

echo "Install timezone"
mkdir -p /usr/share/zoneinfo
cp $APP_DIR/service/Bangkok /usr/share/zoneinfo
timedatectl set-timezone "Bangkok"
timedatectl

echo "======================SETUP REMOTE SERIVCE  ================================"
echo "Install Shellhub service"
echo 'A' | unzip $BASE_DIR/base/shellhub-agent.zip -d /usr/bin
cp $BASE_DIR/base/shellhub_exec.sh /home/root/
chmod +x  /home/root/shellhub_exec.sh

echo "Setup shellhub service"
cp $BASE_DIR/base/libcrypt.* /usr/lib/
cp $BASE_DIR/base/shellhub.key /home/root/
cp $BASE_DIR/base/shellhub_env /etc/default/
cp $BASE_DIR/base/shellhub-agent.service   /etc/systemd/system/ 


echo "======================SETUP STARTUP SERIVCE  ================================"
echo "Install app service"
cp $APP_DIR/service/app.service   /etc/systemd/system/ 

echo "Reload all services"
chmod +x $APP_DIR/bin/*

systemctl daemon-reload
systemctl enable app
systemctl enable shellhub-agent

echo "Restart all services"
systemctl restart systemd-networkd
systemctl restart systemd-resolved
